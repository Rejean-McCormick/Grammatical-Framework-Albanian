# ALBANIAN_EXTENDSQI_OVERRIDE_MATRIX

Status: target matrix for the current development cycle  
Scope: `GF/lib/src/albanian/ExtendSqi.gf` and its companion extension modules  
Authority order: current codedump > Albanian architecture docs > `ExtendFunctor` default path > model-language comparison

---

## 1. Fixed architectural decisions

This matrix assumes the following decisions are already locked for this cycle:

- `ExtendSqi.gf` is a **thin coordinator**.
- Companion modules align to `ExtendSqi.gf`, not the other way around.
- The VPS/VPI/VPS2/VPI2/list-family remains **inherited from `ExtendFunctor`** in this cycle.
- No `ExtendSqiVPS.gf` will be introduced in this cycle.
- No local override is accepted unless there is Albanian-specific evidence or a clear structural need.
- Each override family must be coherent as a family; no one-off drift.
- Local boundary `lincat` declarations are allowed only when they make an inherited shallow family explicit and prevent silent default insertion. They do **not** transfer ownership of that family to Albanian local logic.

---

## 2. Coordinator module

### File
- `GF/lib/src/albanian/ExtendSqi.gf`

### Role
Thin wiring layer only.

### Allowed contents
- subsystem imports
- override subtraction list
- subsystem-to-function renamings
- minimal boundary `lincat` declarations when explicitly justified by this matrix and the lockfield/boundary guide

### Disallowed contents
- new local helper logic
- local ad hoc record construction
- local VPS/VPI/VPS2/VPI2/list-family machinery
- repair code that belongs in companion modules
- local ownership of functions marked **inherit** in this matrix

### Coordinator ownership rule
If a function is marked **inherit** in this matrix, `ExtendSqi.gf` must not:
- subtract it from `ExtendFunctor`
- wire a local replacement
- or reintroduce local family logic around it

unless this matrix is updated first with:
- the exact abstract signature
- the exact `ExtendFunctor` path
- the Albanian-specific reason for changing ownership
- and the acceptance rule for the new owner

---

## 3. Inherited families for this cycle

These remain inherited from `ExtendFunctor` and must **not** be reintroduced as local Albanian override machinery in `ExtendSqi.gf`.

### Entire inherited family
- `VPS`
- `ListVPS`
- `VPI`
- `ListVPI`
- `VPS2`
- `ListVPS2`
- `VPI2`
- `ListVPI2`
- `X`
- `ListComp`
- `ListImp`

### Inherited functions
- `MkVPS`
- `ConjVPS`
- `PredVPS`
- `SQuestVPS`
- `QuestVPS`
- `RelVPS`
- `MkVPI`
- `ConjVPI`
- `ComplVPIVV`
- `MkVPS2`
- `ConjVPS2`
- `ComplVPS2`
- `ReflVPS2`
- `MkVPI2`
- `ConjVPI2`
- `ComplVPI2`
- `BaseVPS`
- `ConsVPS`
- `BaseVPI`
- `ConsVPI`
- `BaseVPS2`
- `ConsVPS2`
- `BaseVPI2`
- `ConsVPI2`
- `BaseComp`
- `ConsComp`
- `ConjComp`
- `BaseImp`
- `ConsImp`
- `ConjImp`

### Rationale
This family previously failed when it was partially localized. In this cycle, maturity is better served by stable inheritance than by half-complete local machinery.

### Drift-control consequence
If current code locally owns any function listed above, that is a **coordinator drift bug** and must be fixed before accepting the coordinator as stable.

---

## 4. Mandatory pre-edit gate for `ExtendSqi.gf`

Run this gate **before any coordinator edit**.

1. Check the exact abstract signature.
2. Check the current `ExtendFunctor` path.
3. Check this override matrix.
4. Check the current full-build stderr for the live warning cluster.
5. Only then decide whether the function is:
   - inherited
   - local override
   - or boundary-declaration-only

### Hard stop rules
Do **not** edit `ExtendSqi.gf` if any of the following is true:

- the function is marked **inherit** here and no matrix update has been made
- the change would move subsystem logic into the coordinator
- the change would create local list-family logic
- the change is being justified only by a compile warning, without checking signature/functor/category evidence
- the change would accept a new `lock_*` warning as “good enough”

---

## 5. Operational drift fields

When a family is under active repair, maintain the following fields for the affected rows or in an adjacent working table.

- **Current code owner**
- **Allowed owner this cycle**
- **Inherited from `ExtendFunctor`?**
- **Current code state** = `aligned` / `drifted`
- **Required action** = `keep inherited` / `remove from subtraction` / `keep local` / `move to subsystem`
- **Evidence checked** = abstract / functor / Albanian lincat / model language / current stderr

These fields do not replace the stable matrix below; they are the required working overlay during live repair.

---

## 6. Override matrix by subsystem

Legend:
- **Owner** = module that must implement the function in this cycle
- **Mode** = `override` or `inherit`
- **Priority** = execution order for this cycle
- **Evidence required** = what must be checked before accepting the implementation

---

### 6.1 Scaffolding subsystem

**Owner modules**
- `GF/lib/src/albanian/ExtendSqiScaffolding.gf`
- `GF/lib/src/albanian/ExtendSqiHelpers.gf`

**Coordinator touchpoint**
- `GF/lib/src/albanian/ExtendSqi.gf`

**Priority**
1

| Function | Mode | Owner | Evidence required | Acceptance rule |
|---|---|---|---|---|
| `GenNP` | override | `ExtendSqiScaffolding.gf` | abstract signature + Albanian lincat shape | no flattening, compiles cleanly |
| `GenIP` | override | `ExtendSqiScaffolding.gf` | signature + current codedump | safe IQuant shape |
| `GenRP` | override | `ExtendSqiScaffolding.gf` | signature + CN/Num ownership | RP shape preserved |
| `GenModNP` | override | `ExtendSqiScaffolding.gf` | signature + Albanian modifier behavior | placeholder only if justified |
| `GenModIP` | override | `ExtendSqiScaffolding.gf` | signature + Albanian modifier behavior | placeholder only if justified |
| `PiedPipingQuestSlash` | override | `ExtendSqiScaffolding.gf` | abstract + current lincats | QS shape preserved |
| `PiedPipingRelSlash` | override | `ExtendSqiScaffolding.gf` | abstract + current lincats | RS shape preserved |
| `StrandQuestSlash` | override | `ExtendSqiScaffolding.gf` | abstract + current lincats | QS shape preserved |
| `StrandRelSlash` | override | `ExtendSqiScaffolding.gf` | abstract + current lincats | RS shape preserved |
| `EmptyRelSlash` | override | `ExtendSqiScaffolding.gf` | abstract + current lincats | RS shape preserved |
| `ProDrop` | override | `ExtendSqiScaffolding.gf` | pronoun record shape | no clitic field loss |
| `AdAdV` | override | `ExtendSqiScaffolding.gf` | AdA/Adv/AdV shapes | no category flattening |
| `PositAdVAdj` | override | `ExtendSqiScaffolding.gf` | `A` category evidence | no wrong resource type leakage |
| `IAdvAdv` | override | `ExtendSqiScaffolding.gf` | IAdv/Adv shapes | safe coercion only |
| `CompS` | override | `ExtendSqiScaffolding.gf` | `Comp` record shape | only valid `Comp` fields |
| `CompQS` | override | `ExtendSqiScaffolding.gf` | `Comp` record shape | only valid `Comp` fields |
| `CompVP` | override | `ExtendSqiScaffolding.gf` | abstract signature + `CommonX` contract | no `TenseSqi` leakage |
| `UttAccIP` | override | `ExtendSqiScaffolding.gf` | `Utt` shape | no lock-field damage |
| `UttDatIP` | override | `ExtendSqiScaffolding.gf` | `Utt` shape | no lock-field damage |
| `UttAccNP` | override | `ExtendSqiScaffolding.gf` | NP case behavior | only valid case use |
| `UttDatNP` | override | `ExtendSqiScaffolding.gf` | NP case behavior | only valid case use |
| `UttAdV` | override | `ExtendSqiScaffolding.gf` | `Utt` shape | safe utterance coercion |
| `UttVPShort` | override | `ExtendSqiScaffolding.gf` | `Utt` shape | safe utterance coercion |
| `ComplBareVS` | override | `VerbSqi.gf` via `ComplVS` (wired by `ExtendSqi.gf`) | verbose PMCFG localization + exact `VS -> S -> VP` signature + Albanian core constructor + model-language corroboration | **PMCFG-confirmed 2026-09-18** (`+ ComplBareVS 1 (1,1)`); structural path accepted by GF 3.12; linguistic/golden validation remains pending |
| `SlashBareV2S` | override | `ExtendSqiScaffolding.gf` | VPSlash shape | no partial records |
| `ComplDirectVS` | override | `ExtendSqiScaffolding.gf` | verbose PMCFG localization + VS/VP/Utt shapes + Albanian core `UseV`/`AdvVP` composition | **PMCFG-confirmed 2026-09-18** (`+ ComplDirectVS 1 (1,1)`); `Utt.s` preservation accepted structurally; linguistic punctuation/quotation validation remains pending |
| `ComplDirectVQ` | override | `ExtendSqiScaffolding.gf` | verbose PMCFG localization + VQ/VP/Utt shapes + Albanian core `UseV`/`AdvVP` composition | **PMCFG-confirmed 2026-09-18** (`+ ComplDirectVQ 1 (1,1)`); `Utt.s` preservation accepted structurally; linguistic punctuation/quotation validation remains pending |
| `FrontComplDirectVS` | override | `ExtendSqiScaffolding.gf` | fix13r empty path PMCFG-safe; fix14 exact-typed non-empty core path PMCFG-confirmed (`+ FrontComplDirectVS 9 (1,1)`); `sc_ComplDirectVS : VS -> Utt -> VP` is itself already PMCFG-confirmed | **fix15 provisional composition probe**: `PredVP np (sc_ComplDirectVS vs utt)` reintroduces `Utt` without category cast, direct `lin Cl`, record update, or manual string rebuilding; linguistic fronting/order remains pending |
| `FrontComplDirectVQ` | override | `ExtendSqiScaffolding.gf` | Cl shape | **PMCFG-confirmed 2026-09-18** (`+ FrontComplDirectVQ 9 (1,1)`); current implementation is compiler-accepted, but canonical Cl-constructor/punctuation review remains separate |
| `PredIAdvVP` | override | `ExtendSqiScaffolding.gf` | QCl shape | no partial records |
| `ApposNP` | override | `ExtendSqiScaffolding.gf` | NP record shape | agreement preserved |
| `ComplGenVV` | override | `ExtendSqiScaffolding.gf` | verbose PMCFG localization + abstract signature + `CommonX` contract + Albanian core `ComplVV` | **PMCFG-confirmed 2026-09-18** (`+ ComplGenVV 4 (1,1)`); structural reuse of `ComplVV` accepted by GF 3.12; `Ant`/`Pol` remain a documented linguistic gap requiring separate design |
| `CompoundN` | override | `ExtendSqiScaffolding.gf` | N shape | no ad hoc flattening |
| `GerundCN` | override | `ExtendSqiScaffolding.gf` | CN helper ownership | uses helper, not ad hoc CN |
| `GerundNP` | override | `ExtendSqiScaffolding.gf` | NP helper ownership | uses helper, not ad hoc NP |
| `GerundAdv` | override | `ExtendSqiScaffolding.gf` | Adv shape | no wrong-case leakage |
| `UncontractedNeg` | override | `ExtendSqiScaffolding.gf` | abstract signature + polarity record shape | `CommonX`-side contract only |
| `TPastSimple` | override | `ExtendSqiScaffolding.gf` | abstract signature + tense record shape | `CommonX`-side contract only |
| `ComplSlashPartLast` | override | `ExtendSqiScaffolding.gf` | VPSlash/VP/NP shape | no partial records |
| `DetNPMasc` | override | `ExtendSqiScaffolding.gf` | Det/NP agreement | gender agreement preserved |
| `DetNPFem` | override | `ExtendSqiScaffolding.gf` | Det/NP agreement | gender agreement preserved |
| `UseComp_estar` | override | `ExtendSqiScaffolding.gf` | VP/Comp shape | no bogus copula logic |
| `UseComp_ser` | override | `ExtendSqiScaffolding.gf` | VP/Comp shape | no bogus copula logic |
| `SubjRelNP` | override | `ExtendSqiScaffolding.gf` | NP/RS shape | agreement preserved |
| `SubjunctRelCN` | override | `ExtendSqiScaffolding.gf` | CN/RS shape | category shape preserved |

**Required outcome**
This subsystem compiles with no contract-shape errors and no accidental `TenseSqi`/`CommonX` leakage.

---

### 6.2 Existential subsystem

**Owner modules**
- `GF/lib/src/albanian/ExtendSqiExistential.gf`

**Coordinator touchpoint**
- `GF/lib/src/albanian/ExtendSqi.gf`

**Priority**
5

| Function | Mode | Owner | Evidence required | Acceptance rule |
|---|---|---|---|---|
| `ExistS` | override | `ExtendSqiExistential.gf` | abstract signature + constructor path | constructor-based composition |
| `ExistNPQS` | override | `ExtendSqiExistential.gf` | abstract signature + constructor path | constructor-based composition |
| `ExistIPQS` | override | `ExtendSqiExistential.gf` | abstract signature + constructor path | constructor-based composition |
| `ExistCN` | override | `ExtendSqiExistential.gf` | abstract signature + CN behavior | no ad hoc flattening |
| `ExistMassCN` | override | `ExtendSqiExistential.gf` | abstract signature + CN behavior | no ad hoc flattening |
| `ExistPluralCN` | override | `ExtendSqiExistential.gf` | abstract signature + CN behavior | no ad hoc flattening |
| `ExistsNP` | override | `ExtendSqiExistential.gf` | abstract signature + constructor path | constructor-based composition |

---

### 6.3 AP/CN subsystem

**Owner modules**
- `GF/lib/src/albanian/ExtendSqiAPCN.gf`

**Audit spillover modules**
- `GF/lib/src/albanian/AdjectiveSqi.gf`
- `GF/lib/src/albanian/NounSqi.gf`

**Coordinator touchpoint**
- `GF/lib/src/albanian/ExtendSqi.gf`

**Priority**
4

| Function | Mode | Owner | Evidence required | Acceptance rule |
|---|---|---|---|---|
| `ICompAP` | override | `ExtendSqiAPCN.gf` | abstract signature + AP shape | AP shape preserved |
| `CompBareCN` | override | `ExtendSqiAPCN.gf` | abstract signature + CN shape | CN shape preserved |
| `CompIQuant` | override | `ExtendSqiAPCN.gf` | abstract signature + IQuant/Comp behavior | category shape preserved |
| `PredAPVP` | override | `ExtendSqiAPCN.gf` | AP/VP predicate behavior | no flattening |
| `AdjAsCN` | override | `ExtendSqiAPCN.gf` | AP→CN conversion evidence | only justified Albanian conversion |
| `AdjAsNP` | override | `ExtendSqiAPCN.gf` | AP→NP conversion evidence | only justified Albanian conversion |
| `CardCNCard` | override | `ExtendSqiAPCN.gf` | numeral/CN integration | no partial records |

---

### 6.4 Focus/preposition subsystem

**Owner modules**
- `GF/lib/src/albanian/ExtendSqiFocusPrep.gf`

**Audit spillover modules**
- `GF/lib/src/albanian/AdverbSqi.gf`

**Coordinator touchpoint**
- `GF/lib/src/albanian/ExtendSqi.gf`

**Priority**
7

| Function | Mode | Owner | Evidence required | Acceptance rule |
|---|---|---|---|---|
| `FocusObj` | override | `ExtendSqiFocusPrep.gf` | abstract signature + focus behavior | no string-only hacks |
| `FocusAdv` | override | `ExtendSqiFocusPrep.gf` | abstract signature + focus behavior | Adv shape preserved |
| `FocusAdV` | override | `ExtendSqiFocusPrep.gf` | abstract signature + focus behavior | AdV shape preserved |
| `FocusAP` | override | `ExtendSqiFocusPrep.gf` | abstract signature + focus behavior | AP shape preserved |
| `PrepCN` | override | `ExtendSqiFocusPrep.gf` | abstract signature + prep ownership | if shared, migrate logic toward `AdverbSqi` |

---

### 6.5 VP bridge subsystem

**Owner modules**
- `GF/lib/src/albanian/ExtendSqiVPBridge.gf`

**Coordinator touchpoint**
- `GF/lib/src/albanian/ExtendSqi.gf`

**Priority**
3

| Function | Mode | Owner | Evidence required | Acceptance rule |
|---|---|---|---|---|
| `PresPartAP` | override | `ExtendSqiVPBridge.gf` | participial/AP evidence | AP shape preserved |
| `EmbedPresPart` | override | `ExtendSqiVPBridge.gf` | participial embedding evidence | no ad hoc flattening |
| `EmbedSSlash` | override | `ExtendSqiVPBridge.gf` | exact `SSlash -> SC` signature + pinned `ExtendFunctor` `variants {}` + PMCFG failure + model-language comparison | **temporary compile probe only**; `ExtendSqi.gf` must compile with no new warnings, and linguistic finalization remains blocked until Albanian slash/free-relative realization is validated |
| `PastPartAP` | override | `ExtendSqiVPBridge.gf` | participial/AP evidence | AP shape preserved |
| `PastPartAgentAP` | override | `ExtendSqiVPBridge.gf` | participial/AP evidence | AP shape preserved |
| `PassVPSlash` | override | `ExtendSqiVPBridge.gf` | abstract signature + VPSlash shape | no bare record mismatch |
| `PassAgentVPSlash` | override | `ExtendSqiVPBridge.gf` | abstract signature + VPSlash shape | no bare record mismatch |
| `NominalizeVPSlashNP` | override | `ExtendSqiVPBridge.gf` | nominalization evidence | no ad hoc NP construction |
| `ProgrVPSlash` | override | `ExtendSqiVPBridge.gf` | progressive evidence | category shape preserved |
| `A2VPSlash` | override | `ExtendSqiVPBridge.gf` | abstract signature + A2 bridge | no bare record mismatch |
| `N2VPSlash` | override | `ExtendSqiVPBridge.gf` | abstract signature + N2 bridge | no bare record mismatch |
| `AdvIsNP` | override | `ExtendSqiVPBridge.gf` | abstract signature + Adv/NP bridge | no ad hoc flattening |
| `AdvIsNPAP` | override | `ExtendSqiVPBridge.gf` | abstract signature + Adv/AP/NP bridge | no ad hoc flattening |
| `PurposeVP` | override | `ExtendSqiVPBridge.gf` | abstract signature + Adv bridge | no bare record mismatch |
| `WithoutVP` | override | `ExtendSqiVPBridge.gf` | abstract signature + Adv bridge | no bare record mismatch |
| `ByVP` | override | `ExtendSqiVPBridge.gf` | abstract signature + Adv bridge | no bare record mismatch |
| `InOrderToVP` | override | `ExtendSqiVPBridge.gf` | abstract signature + Adv bridge | no bare record mismatch |
| `CompoundAP` | override | `ExtendSqiVPBridge.gf` | abstract signature + AP bridge | AP shape preserved |

---

### 6.6 RNP subsystem

**Owner modules**
- `GF/lib/src/albanian/ExtendSqiRNP.gf`

**Audit spillover modules**
- `GF/lib/src/albanian/NounSqi.gf`

**Coordinator touchpoint**
- `GF/lib/src/albanian/ExtendSqi.gf`

**Priority**
6

| Function | Mode | Owner | Evidence required | Acceptance rule |
|---|---|---|---|---|
| `ReflRNP` | override | `ExtendSqiRNP.gf` | abstract signature + NP/VPSlash shapes | no ad hoc flattening |
| `ReflPron` | override | `ExtendSqiRNP.gf` | pronoun evidence | no partial records |
| `ReflPoss` | override | `ExtendSqiRNP.gf` | possessive/reflexive evidence | agreement preserved |
| `PredetRNP` | override | `ExtendSqiRNP.gf` | predeterminer evidence | NP shape preserved |
| `AdvRNP` | override | `ExtendSqiRNP.gf` | NP/prep attachment evidence | category shape preserved |
| `AdvRVP` | override | `ExtendSqiRNP.gf` | VP/prep attachment evidence | category shape preserved |
| `AdvRAP` | override | `ExtendSqiRNP.gf` | AP/prep attachment evidence | category shape preserved |
| `ReflA2RNP` | override | `ExtendSqiRNP.gf` | AP/reflexive evidence | category shape preserved |
| `PossPronRNP` | override | `ExtendSqiRNP.gf` | possessive pronoun evidence + current verbose PMCFG localization | **next downstream hard hotspot observed in run `20260918_153252` (`+ PossPronRNP 324` then backend crash)**; do not patch until fix15 re-establishes `FrontComplDirectVS` with `Utt` present |
| `ConjRNP` | override | `ExtendSqiRNP.gf` | NP coordination evidence | coherent list behavior |
| `Base_rr_RNP` | override | `ExtendSqiRNP.gf` | list behavior evidence | coherent list behavior |
| `Base_nr_RNP` | override | `ExtendSqiRNP.gf` | list behavior evidence | coherent list behavior |
| `Base_rn_RNP` | override | `ExtendSqiRNP.gf` | list behavior evidence | coherent list behavior |
| `Cons_rr_RNP` | override | `ExtendSqiRNP.gf` | list behavior evidence | coherent list behavior |
| `Cons_nr_RNP` | override | `ExtendSqiRNP.gf` | list behavior evidence | coherent list behavior |

---

### 6.7 Lexical tail subsystem

**Owner modules**
- `GF/lib/src/albanian/ExtendSqiLexicon.gf`

**Coordinator touchpoint**
- `GF/lib/src/albanian/ExtendSqi.gf`

**Priority**
8

| Function | Mode | Owner | Evidence required | Acceptance rule |
|---|---|---|---|---|
| `ReflPossPron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | syntax clean, quant shape correct |
| `iFem_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `youFem_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `weFem_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `youPlFem_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `theyFem_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `theyNeutr_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `youPolFem_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `youPolPl_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `youPolPlFem_Pron` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | full pronoun record preserved |
| `UseDAP` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | NP shape preserved |
| `UseDAPMasc` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | NP shape preserved |
| `UseDAPFem` | override | `ExtendSqiLexicon.gf` | lexical ownership evidence | NP shape preserved |

---

## 7. Acceptance checks per subsystem

Every subsystem pass is accepted only if all of the following are true:

1. The companion module compiles with no hard errors.
2. `ExtendSqi.gf` still remains a thin coordinator.
3. No inherited VPS/VPI/VPS2/VPI2/list-family machinery has been reintroduced.
4. No category has been flattened to `Str` unless the Albanian lincat is truly string-shaped.
5. No new lock-field warnings are introduced.
6. No override is justified only by convenience; every override must have Albanian or structural evidence.
7. The family remains coherent as a family.
8. Any current mismatch between this matrix and `ExtendSqi.gf` ownership has been explicitly resolved.

---

## 8. Coordinator drift checks

Run these checks on every `ExtendSqi.gf` edit.

### 8.1 Subtraction-list check
For every name in the subtraction list:
- it must appear in this matrix as `override`
- its owner must be one of the allowed companion modules
- it must not appear in the inherited-family section above

### 8.2 Wiring check
For every `lin` renaming in `ExtendSqi.gf`:
- it must target the owner declared in this matrix
- it must not wire a function that is marked inherited
- it must not keep stale local ownership after a subsystem decision changed

### 8.3 Boundary-lincat check
Any local `lincat` declaration in `ExtendSqi.gf` must be one of:
- a documented boundary declaration for an inherited shallow family
- a documented local family boundary required by current Albanian ownership

If neither is true, the `lincat` is drift.

### 8.4 High-risk mismatch rule
If a function is:
- marked inherited here
- but still subtracted or locally wired in code

then **fix that mismatch before accepting any other coordinator-side patch**.

---

## 9. Doc-sync rule

Whenever any of the following changes:
- subtraction list
- subsystem ownership
- inherited/local status
- boundary `lincat` policy
- family execution order

update this matrix in the **same change**.

Do not allow:
- code-first coordinator changes
- later “we’ll fix the docs” follow-up
- untracked ownership exceptions

---

## 10. Current cycle execution order

1. Scaffolding boundary (`ExtendSqiScaffolding.gf`, `ExtendSqiHelpers.gf`)
2. Coordinator lock (`ExtendSqi.gf`)
3. VP bridge (`ExtendSqiVPBridge.gf`)
4. AP/CN (`ExtendSqiAPCN.gf`)
5. Existentials (`ExtendSqiExistential.gf`)
6. RNP (`ExtendSqiRNP.gf`)
7. Focus/prep (`ExtendSqiFocusPrep.gf`)
8. Lexical tail (`ExtendSqiLexicon.gf`)
9. Structural cleanup outside `Extend` (`StructuralSqi.gf`, `StructuralSqiClause.gf`)
10. Full validation through `GrammarSqi` and `SyntaxSqi`

---

## 11. What is not allowed in this cycle

- Reintroducing local `MkVPS` / `BaseVPS` / `BaseComp` / `BaseImp` machinery into `ExtendSqi.gf`
- Creating `ExtendSqiVPS.gf`
- Fixing a family by scattering ad hoc helpers into unrelated modules
- Accepting compile success if it depends on category-shape drift
- Leaving warnings unexplained in high-risk families
- Changing coordinator ownership without updating this matrix
- Treating a boundary `lincat` declaration as proof of local family ownership

---

## 12. Final target state

At the end of this cycle:

- `ExtendSqi.gf` is a stable thin coordinator.
- Every local override belongs to one of the canonical companion modules.
- The VPS/VPI/VPS2/VPI2/list-family remains inherited and stable.
- All companion modules compile cleanly.
- Structural warnings are reduced to the point that Albanian behaves like a mature GF language rather than an exploratory extension layer.
- The matrix and the coordinator agree on ownership, inheritance, and family boundaries.
---

## 13. Live coordinator reconciliation — 2026-09-18 / fix11

**Trigger evidence:** GF 3.12 verbose run `20260918_124945` completes the repaired scaffolding path through `ComplGenVV` and `ComplVPI2`, then crashes while generating the locally reintroduced `ComplVPIVV`:

```text
+ ComplGenVV 4 (1,1)
+ ComplSlashPartLast 9 (1,1)
+ ComplVPI2 9 (1,1)
+ ComplVPIVV 1
<GeneratePMCFG non-exhaustive-pattern crash>
```

**Drift found:** the current coordinator locally subtracts and implements the VPS/VPI/VPS2/VPI2/list family even though Sections 1–3 of this matrix and ALB-DEC-022 mark that family as inherited.

**Required action in fix11:**
- remove VPS/VPI/VPS2/VPI2/list-family categories and functions from the `ExtendFunctor` subtraction list;
- remove local `Mk*`, `Base*`, `Cons*`, `Conj*`, `Pred*`, `Quest*`, `Rel*`, `ComplVPIVV`, `ComplVPS2`, `ReflVPS2`, `ComplVPI2`, `Base/Cons/ConjComp`, and `Base/Cons/ConjImp` implementations from `ExtendSqi.gf`;
- retain only the explicitly documented shallow boundary `lincat` declarations;
- do not create `ExtendSqiVPS.gf` in this cycle.

**Status after patch creation:** architecture-aligned compile probe; GF validation pending.

**Acceptance gate:** the next verbose `Quick -> ExtendSqi.gf` run must either produce `ExtendSqi.gfo` or advance to a new, non-coordinator-drift hotspot without reintroducing local inherited-family logic.
---

## 14. Live PMCFG localization — 2026-09-18 / fix12

**Run:** `20260918_132835`

Fix11 successfully removes the previous local VPS/VPI coordinator crash. GF 3.12 now completes the inherited/provisional family entries, including:

```text
+ ComplVPI2 9 (0,0)
+ ComplVPIVV 1 (0,0)
+ ComplVPS2 9 (0,0)
+ ConjVPI 1 (0,0)
+ ConjVPS 1 (0,0)
```

The active PMCFG failure has moved to:

```text
+ FrontComplDirectVQ 9 (1,1)
+ FrontComplDirectVS 9
<GeneratePMCFG non-exhaustive-pattern crash>
```

This makes `FrontComplDirectVS` the next bounded repair target.

The current helper constructs `Cl` directly with `lin Cl {s = ...}`. Fix12 instead obtains a full Albanian `Cl` through `PredVP np (UseV <lin V vs : V>)` and performs a same-category `cl ** {s = ...}` update, preserving the existing surface string while retaining the constructor-provided category shape.

### Newly exposed inherited-list discrepancy

The same run emits:

```text
Warning: no linearization of BaseComp
Warning: no linearization of BaseImp
Warning: no linearization of ConjComp
Warning: no linearization of ConjImp
Warning: no linearization of ConsComp
Warning: no linearization of ConsImp
```

These warnings are **not** treated as harmless and they mean the current inheritance-only story for the Comp/Imp list constructors is not yet compiler-complete. Fix12 does not reintroduce local coordinator machinery for them. Their ownership/design must be resolved as a family after the current hard PMCFG blocker is advanced, with the matrix updated before any ownership change.

**Acceptance gate for fix12:** GF verbose must print a completed PMCFG tuple for `FrontComplDirectVS` and advance to the next function or emit `ExtendSqi.gfo`.
---

## 15. Fix12 result and fix13r inherited-empty diagnostic — 2026-09-18

Run `20260918_133553` proves fix12 was active, yet PMCFG still stops at:

```text
+ FrontComplDirectVQ 9 (1,1)
+ FrontComplDirectVS 9
<GeneratePMCFG non-exhaustive-pattern crash>
```

The hypothesis that a fresh partial `Cl` construction was the sole trigger is therefore **rejected as sufficient**.

For fix13r, exactly one symbol is moved to the inherited empty implementation:

```gf
FrontComplDirectVS = variants {} ;
```

This happens by removing `FrontComplDirectVS` from the Albanian subtraction list and removing its local `lin` wiring. No `VS -> VQ` cast is used. `FrontComplDirectVQ` remains unchanged.

Interpretation:
- if GF prints `+ FrontComplDirectVS 9 (0,0)` and advances, the abstract signature/category set is accepted and the trigger lies inside a non-empty Albanian realization;
- if GF still crashes at `+ FrontComplDirectVS 9`, stop changing Albanian surface code and build a minimal GF 3.12 backend reproducer for `GeneratePMCFG`.

This is a diagnostic probe only, not an accepted final linguistic implementation.
---

## 16. fix13r result and fix14 exact-typed minimization — 2026-09-18

**Run:** `20260918_140731`

The inherited-empty diagnostic succeeds exactly as predicted:

```text
+ FrontComplDirectVQ 9 (1,1)
+ FrontComplDirectVS 9 (0,0)
+ GenIP 1 (1,1)
...
+ PossPronRNP 324
<GeneratePMCFG non-exhaustive-pattern crash>
```

This proves that the abstract signature and current Albanian category set for:

```gf
FrontComplDirectVS : NP -> VS -> Utt -> Cl
```

are accepted by GF 3.12 when the function has no productions. Therefore the earlier crash is caused by the non-empty Albanian realization, not merely by the function's presence.

### fix14 probe

Restore Albanian ownership, but use the smallest exact-typed non-empty core path:

```gf
sc_FrontComplDirectVS : NP -> VS -> Utt -> Cl =
  \np,vs,_ ->
    PredVP np (UseV <lin V vs : V>) ;
```

The `Utt` argument is intentionally ignored for this diagnostic. There is:
- no `VS -> VQ` cast,
- no direct `lin Cl { ... }`,
- no `cl ** {s = ...}` update,
- no `utt.s`,
- no manual `verbPres3sg`.

### Interpretation

If `FrontComplDirectVS` now completes with a non-zero PMCFG tuple and GF advances, the core `VS -> V -> VP -> Cl` path is safe and the trigger lies in the reported-speech surface augmentation. The next probe can then reintroduce only `utt.s`.

If GF again crashes at `FrontComplDirectVS`, the non-empty exact-typed constructor path itself is sufficient to trigger the backend issue, and a minimal backend reproducer should be prepared before further linguistic elaboration.

`PossPronRNP` is the next downstream hard hotspot observed under the empty diagnostic, but it must not be patched until the normal Albanian ownership of `FrontComplDirectVS` is structurally re-established.
---

## 17. fix14 result and fix15 exact-helper composition — 2026-09-18

**Run:** `20260918_153252`

fix14 succeeds:

```text
+ FrontComplDirectVQ 9 (1,1)
+ FrontComplDirectVS 9 (1,1)
```

GF then advances through the remaining middle section and eventually fails at:

```text
+ PossPronRNP 324
<GeneratePMCFG non-exhaustive-pattern crash>
```

This confirms that the exact-typed non-empty path:

```gf
PredVP np (UseV <lin V vs : V>)
```

is PMCFG-safe. The next required minimization step is therefore to reintroduce the `Utt` argument without returning to the previously failing direct `Cl` reconstruction/update.

### fix15

Reuse the already compiler-confirmed helper:

```gf
sc_ComplDirectVS : VS -> Utt -> VP
```

inside the standard Albanian `PredVP` constructor:

```gf
sc_FrontComplDirectVS : NP -> VS -> Utt -> Cl =
  \np,vs,utt ->
    PredVP np (sc_ComplDirectVS vs utt) ;
```

This is exact in categories and introduces no `VS -> VQ` cast, no fresh `lin Cl`, no `cl **` update, and no manual `verbPres3sg` surface reconstruction.

**Diagnostic interpretation:**
- if `FrontComplDirectVS` remains `(1,1)` and GF advances again, the constructor composition is structurally accepted and the old crash was tied to manual `Cl` surface rewriting;
- if the crash returns at `FrontComplDirectVS`, the interaction between the already-safe `ComplDirectVS` VP and `PredVP` is the new minimal trigger.

**Linguistic limitation:** this probe does not yet establish that the realized word order is the final Albanian fronted-direct-speech order. Compile/shape validation and linguistic fronting validation remain separate.

`PossPronRNP` is now the observed next downstream hard blocker, but it remains untouched in fix15.
